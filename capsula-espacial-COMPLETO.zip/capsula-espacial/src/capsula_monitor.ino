/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║       SISTEMA IoT - MONITORAMENTO DE CÁPSULA ESPACIAL       ║
 * ║                   FIAP - Global Solution 2026               ║
 * ╠══════════════════════════════════════════════════════════════╣
 * ║  Microcontrolador : ESP32                                   ║
 * ║  Sensores         : DHT22 (Temp/Umid), LDR (Luz), MPU6050  ║
 * ║  Display          : LCD 16x2 I2C                           ║
 * ║  Plataforma       : Wokwi Simulator                        ║
 * ╚══════════════════════════════════════════════════════════════╝
 *
 * Grandezas monitoradas:
 *   - Temperatura interna da cápsula (°C)
 *   - Luminosidade (% e lux simulado)
 *   - Vibração / aceleração (eixo Z, m/s²)
 *
 * Alertas:
 *   - LED vermelho + buzzer em condições críticas
 *   - Serial Monitor com log de timestamps
 */

#include <Wire.h>
#include <LiquidCrystal_I2C.h>
#include <DHT.h>

// ─── Pinagem ────────────────────────────────────────────────────
#define DHT_PIN      4       // Sensor DHT22
#define DHT_TYPE     DHT22
#define LDR_PIN      34      // Fotoresistor (entrada analógica)
#define VIBR_PIN     35      // Sensor de vibração analógico (simula MPU)
#define LED_GREEN    25      // LED status OK
#define LED_YELLOW   26      // LED atenção
#define LED_RED      27      // LED alerta crítico
#define BUZZER_PIN   14      // Buzzer ativo

// ─── Limites de alerta ──────────────────────────────────────────
#define TEMP_MIN     18.0    // °C mínimo seguro
#define TEMP_MAX     35.0    // °C máximo seguro
#define LUZ_CRITICA  15      // % abaixo = escuridão crítica
#define VIBR_CRITICA 600     // unidade ADC acima = vibração crítica

// ─── Display LCD I2C (endereço 0x27, 16 colunas, 2 linhas) ──────
LiquidCrystal_I2C lcd(0x27, 16, 2);

// ─── Sensor DHT22 ───────────────────────────────────────────────
DHT dht(DHT_PIN, DHT_TYPE);

// ─── Variáveis globais ──────────────────────────────────────────
float temperatura    = 0.0;
float umidade        = 0.0;
int   luminosidade   = 0;     // 0–100%
int   vibracao       = 0;     // valor ADC bruto
unsigned long ultimaLeitura = 0;
unsigned long contadorAlertas = 0;
int  telaAtual = 0;            // rotação entre telas do LCD

// ─── Caracteres customizados ────────────────────────────────────
byte iconTemp[8]  = {0x04,0x0A,0x0A,0x0E,0x0E,0x1F,0x1F,0x0E};
byte iconLuz[8]   = {0x00,0x0E,0x1F,0x1F,0x1F,0x0E,0x00,0x04};
byte iconVibr[8]  = {0x15,0x0A,0x15,0x0A,0x15,0x0A,0x15,0x0A};
byte iconOk[8]    = {0x00,0x01,0x02,0x14,0x08,0x00,0x00,0x00};

// ════════════════════════════════════════════════════════════════
void setup() {
  Serial.begin(115200);
  delay(500);

  Serial.println(F("=============================================="));
  Serial.println(F("  CAPSULA ESPACIAL - SISTEMA IoT INICIANDO   "));
  Serial.println(F("  FIAP Global Solution 2026                  "));
  Serial.println(F("=============================================="));

  // LEDs e buzzer
  pinMode(LED_GREEN,  OUTPUT);
  pinMode(LED_YELLOW, OUTPUT);
  pinMode(LED_RED,    OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  digitalWrite(BUZZER_PIN, LOW);

  // Teste de inicialização dos LEDs (sequência de boot)
  sequenciaBoot();

  // LCD
  lcd.init();
  lcd.backlight();
  lcd.createChar(0, iconTemp);
  lcd.createChar(1, iconLuz);
  lcd.createChar(2, iconVibr);
  lcd.createChar(3, iconOk);

  telaSplash();

  // DHT22
  dht.begin();
  delay(2000);

  Serial.println(F("[OK] Sistema inicializado. Iniciando leitura...\n"));
  Serial.println(F("Timestamp(ms) | Temp(C) | Umid(%) | Luz(%) | Vibr(ADC) | Status"));
  Serial.println(F("-------------|---------|---------|--------|-----------|--------"));
}

// ════════════════════════════════════════════════════════════════
void loop() {
  unsigned long agora = millis();

  // Leitura a cada 2 segundos
  if (agora - ultimaLeitura >= 2000) {
    ultimaLeitura = agora;
    lerSensores();
    avaliarAlertas();
    exibirNoLCD();
    logSerial(agora);
    telaAtual = (telaAtual + 1) % 3;
  }
}

// ════════════════════════════════════════════════════════════════
void lerSensores() {
  // DHT22 — temperatura e umidade
  float t = dht.readTemperature();
  float h = dht.readHumidity();
  if (!isnan(t)) temperatura = t;
  if (!isnan(h)) umidade     = h;

  // LDR — converte ADC (0–4095) para porcentagem
  int ldrRaw   = analogRead(LDR_PIN);
  luminosidade = map(ldrRaw, 0, 4095, 0, 100);

  // Vibração — ADC bruto (simula acelerômetro no eixo Z)
  vibracao = analogRead(VIBR_PIN);
}

// ─── Avalia condições e aciona alertas ──────────────────────────
void avaliarAlertas() {
  bool alertaCritico = false;
  bool alertaAtencao = false;

  if (temperatura < TEMP_MIN || temperatura > TEMP_MAX) alertaCritico = true;
  if (luminosidade < LUZ_CRITICA)                        alertaCritico = true;
  if (vibracao > VIBR_CRITICA)                           alertaCritico = true;

  // Zona de atenção (10% antes do limite crítico)
  if (temperatura > TEMP_MAX * 0.9 || temperatura < TEMP_MIN * 1.1) alertaAtencao = true;
  if (luminosidade < LUZ_CRITICA + 10)                               alertaAtencao = true;

  if (alertaCritico) {
    digitalWrite(LED_RED,    HIGH);
    digitalWrite(LED_YELLOW, LOW);
    digitalWrite(LED_GREEN,  LOW);
    buzzerAlerta();
    contadorAlertas++;
  } else if (alertaAtencao) {
    digitalWrite(LED_RED,    LOW);
    digitalWrite(LED_YELLOW, HIGH);
    digitalWrite(LED_GREEN,  LOW);
  } else {
    digitalWrite(LED_RED,    LOW);
    digitalWrite(LED_YELLOW, LOW);
    digitalWrite(LED_GREEN,  HIGH);
  }
}

// ─── Rotação de telas no LCD 16x2 ───────────────────────────────
void exibirNoLCD() {
  lcd.clear();

  if (telaAtual == 0) {
    // Tela 1: Temperatura e status
    lcd.setCursor(0, 0);
    lcd.write(byte(0));
    lcd.print(F(" TEMP: "));
    lcd.print(temperatura, 1);
    lcd.print(F("\xDF" "C"));

    lcd.setCursor(0, 1);
    lcd.print(F("UMID: "));
    lcd.print(umidade, 1);
    lcd.print(F("%"));

  } else if (telaAtual == 1) {
    // Tela 2: Luminosidade
    lcd.setCursor(0, 0);
    lcd.write(byte(1));
    lcd.print(F(" LUZ: "));
    lcd.print(luminosidade);
    lcd.print(F("%"));

    lcd.setCursor(0, 1);
    // Barra visual de luminosidade
    int barras = map(luminosidade, 0, 100, 0, 16);
    for (int i = 0; i < 16; i++) {
      lcd.print(i < barras ? (char)255 : '-');
    }

  } else {
    // Tela 3: Vibração e alertas
    lcd.setCursor(0, 0);
    lcd.write(byte(2));
    lcd.print(F(" VIBR: "));
    lcd.print(vibracao);

    lcd.setCursor(0, 1);
    lcd.print(F("ALERTAS: "));
    lcd.print(contadorAlertas);

    // Status geral
    bool critico = (temperatura < TEMP_MIN || temperatura > TEMP_MAX ||
                    luminosidade < LUZ_CRITICA || vibracao > VIBR_CRITICA);
    lcd.setCursor(14, 1);
    lcd.print(critico ? "!!" : "OK");
  }
}

// ─── Log serial formatado ────────────────────────────────────────
void logSerial(unsigned long ts) {
  bool critico = (temperatura < TEMP_MIN || temperatura > TEMP_MAX ||
                  luminosidade < LUZ_CRITICA || vibracao > VIBR_CRITICA);

  Serial.print(ts);
  Serial.print(F("\t| "));
  Serial.print(temperatura, 2);
  Serial.print(F("\t| "));
  Serial.print(umidade, 2);
  Serial.print(F("\t| "));
  Serial.print(luminosidade);
  Serial.print(F("\t| "));
  Serial.print(vibracao);
  Serial.print(F("\t| "));
  Serial.println(critico ? F("ALERTA!") : F("normal"));
}

// ─── Tela de splash no boot ──────────────────────────────────────
void telaSplash() {
  lcd.clear();
  lcd.setCursor(2, 0);
  lcd.print(F("FIAP  SPACE"));
  lcd.setCursor(1, 1);
  lcd.print(F("IoT Monitor v1.0"));
  delay(2500);
  lcd.clear();
  lcd.setCursor(0, 0);
  lcd.print(F("Inicializando..."));
  delay(1500);
}

// ─── Sequência visual de boot (LEDs) ────────────────────────────
void sequenciaBoot() {
  int leds[] = {LED_GREEN, LED_YELLOW, LED_RED};
  for (int i = 0; i < 3; i++) {
    digitalWrite(leds[i], HIGH);
    delay(200);
    digitalWrite(leds[i], LOW);
  }
  for (int i = 2; i >= 0; i--) {
    digitalWrite(leds[i], HIGH);
    delay(200);
    digitalWrite(leds[i], LOW);
  }
}

// ─── Buzzer — padrão Morse SOS ──────────────────────────────────
void buzzerAlerta() {
  // Três bipes curtos
  for (int i = 0; i < 3; i++) {
    digitalWrite(BUZZER_PIN, HIGH);
    delay(80);
    digitalWrite(BUZZER_PIN, LOW);
    delay(80);
  }
}
